import React, { useState, useRef } from 'react';
import { ViewImage } from '../types';
import { ImageInfoOverlay } from './ImageInfoOverlay';

interface SplitViewProps {
  images: ViewImage[];
  showInfo: boolean;
}

export function SplitView({ images, showInfo }: SplitViewProps) {
  const [sliderValue, setSliderValue] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);
  const [leftIdx, setLeftIdx] = useState(0);
  const [rightIdx, setRightIdx] = useState(1);

  if (images.length < 2) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-white rounded-2xl shadow-sm border border-gray-200 text-gray-400 font-medium">
        請選擇至少兩張圖片進行左右比對
      </div>
    );
  }

  const safeLeftIdx = Math.min(leftIdx, images.length - 1);
  const safeRightIdx = Math.min(rightIdx, images.length - 1);

  const img1 = images[safeLeftIdx];
  const img2 = images[safeRightIdx];

  return (
    <div 
      ref={containerRef}
      className="relative w-full h-full bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden select-none"
    >
      {/* Dropdowns */}
      <div className="absolute top-4 left-1/2 -translate-x-full pr-8 z-50">
        <select 
          value={safeLeftIdx} 
          onChange={e => setLeftIdx(Number(e.target.value))}
          className="bg-black/70 text-white text-xs rounded-lg px-3 py-1.5 backdrop-blur-md border border-white/20 outline-none cursor-pointer shadow-lg"
        >
          {images.map((img, i) => <option key={i} value={i}>{img.label}</option>)}
        </select>
      </div>
      <div className="absolute top-4 left-1/2 pl-8 z-50">
        <select 
          value={safeRightIdx} 
          onChange={e => setRightIdx(Number(e.target.value))}
          className="bg-black/70 text-white text-xs rounded-lg px-3 py-1.5 backdrop-blur-md border border-white/20 outline-none cursor-pointer shadow-lg"
        >
          {images.map((img, i) => <option key={i} value={i}>{img.label}</option>)}
        </select>
      </div>

      {/* Base Image (Image 1) */}
      <img 
        src={img1.url} 
        alt={img1.label} 
        className="absolute inset-0 w-full h-full object-contain pointer-events-none" 
      />
      {showInfo && <ImageInfoOverlay file={img1.file} label={img1.label} position="left" />}
      
      {/* Overlay Image (Image 2) */}
      <div 
        className="absolute inset-0 w-full h-full overflow-hidden pointer-events-none"
        style={{ clipPath: `inset(0 ${100 - sliderValue}% 0 0)` }}
      >
        <img 
          src={img2.url} 
          alt={img2.label} 
          className="absolute inset-0 w-full h-full object-contain" 
        />
        {showInfo && <ImageInfoOverlay file={img2.file} label={img2.label} position="right" />}
      </div>

      {/* Slider Input */}
      <input 
        type="range" 
        min="0" 
        max="100" 
        value={sliderValue} 
        onChange={e => setSliderValue(Number(e.target.value))}
        className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-20 m-0"
      />

      {/* Visual Slider Line */}
      <div 
        className="absolute top-0 bottom-0 w-1 bg-white pointer-events-none z-10 shadow-[0_0_10px_rgba(0,0,0,0.3)]" 
        style={{ left: `calc(${sliderValue}% - 2px)` }}
      >
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full shadow-md border border-gray-200 flex items-center justify-center">
          <div className="flex gap-1">
            <div className="w-0.5 h-3 bg-gray-400 rounded-full"></div>
            <div className="w-0.5 h-3 bg-gray-400 rounded-full"></div>
          </div>
        </div>
      </div>
    </div>
  );
}
