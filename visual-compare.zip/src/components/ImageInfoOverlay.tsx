import React, { useEffect, useState } from 'react';
import exifr from 'exifr';

interface ImageInfoOverlayProps {
  file: File;
  label: string;
  position?: 'left' | 'right' | 'top' | 'bottom' | 'static';
}

export function ImageInfoOverlay({ file, label, position = 'left' }: ImageInfoOverlayProps) {
  const [meta, setMeta] = useState<any>(null);

  useEffect(() => {
    exifr.parse(file).then(setMeta).catch(() => {});
  }, [file]);

  let posClass = '';
  if (position === 'left') posClass = 'absolute top-4 left-4 text-left max-w-xs';
  else if (position === 'right') posClass = 'absolute top-4 right-4 text-right items-end max-w-xs';
  else if (position === 'top') posClass = 'absolute top-4 left-4 text-left max-w-xs';
  else if (position === 'bottom') posClass = 'absolute bottom-4 left-4 text-left max-w-xs';
  else if (position === 'static') posClass = 'relative text-left w-full';

  const isStatic = position === 'static';

  return (
    <div className={`${posClass} ${isStatic ? 'p-1' : 'bg-black/75 p-2 rounded-xl backdrop-blur-md shadow-lg'} text-[10px] text-white z-50 pointer-events-none flex flex-col`}>
      <div className={`font-bold text-blue-300 mb-1 text-[11px]`}>{label}</div>
      <div className="grid grid-cols-2 gap-x-2 gap-y-0.5 w-full leading-tight">
        <div className="col-span-2"><span className="text-gray-400">檔名:</span> <span className="break-all">{file.name}</span></div>
        <div><span className="text-gray-400">大小:</span> {(file.size / 1024 / 1024).toFixed(2)} MB</div>
        <div><span className="text-gray-400">修改:</span> {new Date(file.lastModified).toLocaleString()}</div>
        {meta?.DateTimeOriginal && <div><span className="text-gray-400">拍攝:</span> {new Date(meta.DateTimeOriginal).toLocaleString()}</div>}
        {meta?.ExifImageWidth && <div><span className="text-gray-400">尺寸:</span> {meta.ExifImageWidth} x {meta.ExifImageHeight}</div>}
        {meta?.Software && <div className="col-span-2"><span className="text-gray-400">軟體:</span> {meta.Software}</div>}
      </div>
    </div>
  );
}
