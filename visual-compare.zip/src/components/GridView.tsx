import React, { useRef, useState } from 'react';
import { toPng } from 'html-to-image';
import { Download, ZoomIn, ZoomOut } from 'lucide-react';
import { ViewImage } from '../types';
import { ImageInfoOverlay } from './ImageInfoOverlay';

interface GridViewProps {
  images: ViewImage[];
  showInfo: boolean;
}

export function GridView({ images, showInfo }: GridViewProps) {
  const gridRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1); // Default to 1x
  const [pan, setPan] = useState({ x: 50, y: 50 });
  
  // Take up to 4 images
  const displayImages = images.slice(0, 4);
  
  // Determine grid columns based on number of images
  const isThreeImages = displayImages.length === 3;
  const hasBottomRow = displayImages.length === 4;

  let gridTemplateRows = '';
  if (showInfo) {
    if (hasBottomRow) {
      gridTemplateRows = 'auto auto 8px auto auto';
    } else {
      gridTemplateRows = 'auto auto';
    }
  } else {
    if (hasBottomRow) {
      gridTemplateRows = 'auto 8px auto';
    } else {
      gridTemplateRows = 'auto';
    }
  }

  let gridTemplateColumns = 'minmax(0, 1fr)';
  if (displayImages.length === 2 || displayImages.length === 4) {
    gridTemplateColumns = 'repeat(2, minmax(0, 1fr))';
  } else if (displayImages.length === 3) {
    gridTemplateColumns = 'repeat(3, minmax(0, 1fr))';
  }

  const handleDownload = React.useCallback(async (e?: React.MouseEvent | Event) => {
    if (e) e.stopPropagation();
    if (!gridRef.current) return;
    try {
      // Removed cacheBust: true as it breaks blob: URLs
      const dataUrl = await toPng(gridRef.current, { 
        quality: 1.0,
        pixelRatio: 2 // Higher quality export
      });
      const a = document.createElement('a');
      a.href = dataUrl;
      const baseName = displayImages[0]?.file.name.split('.')[0] || 'grid-comparison';
      a.download = `${baseName}-grid.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (err) {
      console.error('Failed to download grid image', err);
      alert('下載網格圖失敗，請稍後再試');
    }
  }, [displayImages]);

  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (e.key === 's' || e.key === 'S') {
        e.preventDefault();
        handleDownload();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleDownload]);

  const handleGridClick = () => {
    setScale(s => s === 1 ? 2 : s === 2 ? 4 : s === 4 ? 8 : 1);
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (scale === 1) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setPan({ x, y });
  };

  if (displayImages.length === 0) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-white rounded-2xl shadow-sm border border-gray-200 text-gray-400 font-medium">
        請選擇圖片進行四宮格比對
      </div>
    );
  }

  const renderExif = (img: ViewImage, row: number, col: number, isTop: boolean) => (
    <div
      key={`exif-${img.id}`}
      className={`bg-[#1a1a1a] ${isTop ? 'rounded-t-xl border-b' : 'rounded-b-xl border-t'} border-white/10 flex ${isTop ? 'items-end pb-2' : 'items-start pt-2'} px-3`}
      style={{ gridRow: row, gridColumn: col }}
      onMouseMove={handleMouseMove}
    >
      <ImageInfoOverlay file={img.file} label={img.label} position="static" />
    </div>
  );

  const renderImg = (img: ViewImage, row: number, col: number, isTop: boolean, isBottom: boolean) => (
    <div
      key={`img-${img.id}`}
      className={`bg-[#1a1a1a] relative overflow-hidden flex items-center justify-center ${!showInfo ? 'rounded-xl' : ''} ${showInfo && isTop ? 'rounded-b-xl' : ''} ${showInfo && isBottom ? 'rounded-t-xl' : ''}`}
      style={{ gridRow: row, gridColumn: col }}
      onMouseMove={handleMouseMove}
    >
      <img
        src={img.url}
        alt={img.label}
        className="w-full h-auto block object-contain transition-transform duration-75 ease-out pointer-events-none"
        style={{
          transform: `scale(${scale})`,
          transformOrigin: `${pan.x}% ${pan.y}%`
        }}
      />
    </div>
  );

  const elements: React.ReactNode[] = [];
  displayImages.forEach((img, idx) => {
    const isTopRow = isThreeImages ? true : idx < 2;
    const col = isThreeImages ? idx + 1 : (idx % 2) + 1;

    if (isTopRow) {
      if (showInfo) {
        elements.push(renderExif(img, 1, col, true));
        elements.push(renderImg(img, 2, col, true, false));
      } else {
        elements.push(renderImg(img, 1, col, true, false));
      }
    } else {
      if (showInfo) {
        elements.push(renderImg(img, 4, col, false, true));
        elements.push(renderExif(img, 5, col, false));
      } else {
        elements.push(renderImg(img, 3, col, false, true));
      }
    }
  });

  return (
    <div className="relative w-full h-full flex flex-col bg-black rounded-2xl overflow-hidden">
      <div className="absolute top-4 right-4 z-[1000] flex gap-2 pointer-events-none">
        <div className="bg-gray-900/90 backdrop-blur-sm text-white px-3 py-2 rounded-full text-xs font-medium flex items-center gap-1 shadow-lg pointer-events-auto">
          {scale === 1 ? <ZoomOut className="w-3 h-3" /> : <ZoomIn className="w-3 h-3" />}
          <select 
            value={scale}
            onChange={(e) => setScale(Number(e.target.value))}
            className="bg-transparent text-white outline-none cursor-pointer font-medium"
          >
            <option value={1} className="text-gray-900">1x</option>
            <option value={2} className="text-gray-900">2x</option>
            <option value={4} className="text-gray-900">4x</option>
            <option value={8} className="text-gray-900">8x</option>
          </select>
        </div>
        <button 
          onClick={handleDownload}
          className="flex items-center gap-2 px-4 py-2 bg-gray-900/90 backdrop-blur-sm text-white rounded-full font-medium hover:bg-gray-800 transition-colors shadow-lg text-sm pointer-events-auto"
        >
          <Download className="w-4 h-4" />
          下載網格圖
        </button>
      </div>
      
      <div 
        className="flex-1 overflow-y-auto cursor-crosshair p-2 relative z-0"
        onClick={handleGridClick}
      >
        <div 
          ref={gridRef} 
          className="w-full min-h-full grid bg-black"
          style={{
            gridTemplateColumns,
            gridTemplateRows,
            columnGap: '8px'
          }}
        >
          {elements}
        </div>
      </div>
    </div>
  );
}
