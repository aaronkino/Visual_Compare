import React, { useState } from 'react';
import { ViewImage } from '../types';
import { ImageInfoOverlay } from './ImageInfoOverlay';

interface SequenceViewProps {
  images: ViewImage[];
  showInfo: boolean;
}

export function SequenceView({ images, showInfo }: SequenceViewProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  if (images.length === 0) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-white rounded-2xl shadow-sm border border-gray-200 text-gray-400 font-medium">
        請選擇圖片進行切換比對
      </div>
    );
  }

  // Ensure index is within bounds if images array changes
  const safeIndex = Math.min(currentIndex, images.length - 1);
  const currentImage = images[safeIndex];

  const handleNext = (e: React.MouseEvent) => {
    e.preventDefault(); // Prevent context menu
    setCurrentIndex((prev) => (prev + 1) % images.length);
  };

  const handlePrev = (e: React.MouseEvent) => {
    if (e.button === 0) {
      setCurrentIndex((prev) => (prev - 1 + images.length) % images.length);
    }
  };

  return (
    <div className="relative w-full h-full bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden select-none flex flex-col">
      {/* Main Image Area */}
      <div 
        className="flex-1 relative overflow-hidden cursor-pointer bg-[#1a1a1a]"
        onClick={handlePrev}
        onContextMenu={handleNext}
        title="左鍵：上一張 / 右鍵：下一張"
      >
        <img 
          src={currentImage.url} 
          alt={currentImage.label} 
          className="absolute inset-0 w-full h-full object-contain pointer-events-none" 
        />
        {showInfo && <ImageInfoOverlay file={currentImage.file} label={currentImage.label} position="left" />}
        
        {/* Overlay Hint */}
        <div className="absolute top-4 right-4 bg-black/60 text-white text-xs px-3 py-1.5 rounded-full backdrop-blur-md pointer-events-none shadow-lg border border-white/10">
          左鍵: 上一張 | 右鍵: 下一張
        </div>
      </div>
      
      {/* Bottom Navigation Bar */}
      <div className="h-20 bg-white border-t border-gray-200 flex items-center px-6 gap-6 shrink-0">
        <div className="text-sm font-bold text-gray-500 w-12 text-right font-mono">
          {safeIndex + 1} / {images.length}
        </div>
        
        <input 
          type="range" 
          min={0} 
          max={images.length - 1} 
          value={safeIndex}
          onChange={(e) => setCurrentIndex(Number(e.target.value))}
          className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-gray-900"
        />
        
        <div className="flex gap-2">
          {images.map((img, idx) => (
            <button
              key={img.id}
              onClick={() => setCurrentIndex(idx)}
              className={`w-12 h-12 rounded-lg overflow-hidden border-2 transition-all ${idx === safeIndex ? 'border-gray-900 shadow-md scale-110 z-10' : 'border-transparent opacity-60 hover:opacity-100'}`}
              title={img.label}
            >
              <img src={img.url} alt="" className="w-full h-full object-cover" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
