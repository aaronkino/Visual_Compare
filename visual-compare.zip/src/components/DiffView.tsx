import React, { useState, useEffect, useRef } from 'react';
import pixelmatch from 'pixelmatch';
import { Download, Loader2 } from 'lucide-react';
import { ViewImage } from '../types';
import { ImageInfoOverlay } from './ImageInfoOverlay';

interface DiffViewProps {
  images: ViewImage[];
  showInfo: boolean;
}

export function DiffView({ images, showInfo }: DiffViewProps) {
  const [diffUrl, setDiffUrl] = useState<string | null>(null);
  const [isComputing, setIsComputing] = useState(false);

  useEffect(() => {
    if (images.length < 2) return;
    
    let isMounted = true;

    async function computeDiff() {
      setIsComputing(true);
      try {
        const img1 = new Image();
        const img2 = new Image();
        
        await Promise.all([
          new Promise((resolve, reject) => { 
            img1.onload = resolve; 
            img1.onerror = reject;
            img1.src = images[0].url; 
          }),
          new Promise((resolve, reject) => { 
            img2.onload = resolve; 
            img2.onerror = reject;
            img2.src = images[1].url; 
          })
        ]);

        if (!isMounted) return;

        const width = Math.max(img1.width, img2.width);
        const height = Math.max(img1.height, img2.height);

        const canvas1 = document.createElement('canvas');
        canvas1.width = width; 
        canvas1.height = height;
        const ctx1 = canvas1.getContext('2d')!;
        ctx1.drawImage(img1, 0, 0, width, height);
        const data1 = ctx1.getImageData(0, 0, width, height);

        const canvas2 = document.createElement('canvas');
        canvas2.width = width; 
        canvas2.height = height;
        const ctx2 = canvas2.getContext('2d')!;
        ctx2.drawImage(img2, 0, 0, width, height);
        const data2 = ctx2.getImageData(0, 0, width, height);

        const diffCanvas = document.createElement('canvas');
        diffCanvas.width = width; 
        diffCanvas.height = height;
        const diffCtx = diffCanvas.getContext('2d')!;
        const diffData = diffCtx.createImageData(width, height);

        pixelmatch(data1.data, data2.data, diffData.data, width, height, {
          threshold: 0.1,
          diffColor: [255, 0, 0]
        });

        diffCtx.putImageData(diffData, 0, 0);
        
        if (isMounted) {
          setDiffUrl(diffCanvas.toDataURL('image/png'));
        }
      } catch (error) {
        console.error("Failed to compute diff:", error);
      } finally {
        if (isMounted) {
          setIsComputing(false);
        }
      }
    }

    computeDiff();

    return () => {
      isMounted = false;
    };
  }, [images]);

  const handleDownload = () => {
    if (!diffUrl) return;
    const a = document.createElement('a');
    a.href = diffUrl;
    a.download = 'diff-image.png';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  if (images.length < 2) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-white rounded-2xl shadow-sm border border-gray-200 text-gray-400 font-medium">
        請選擇至少兩張圖片進行差異比對
      </div>
    );
  }

  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
      {isComputing ? (
        <div className="flex flex-col items-center text-gray-500">
          <Loader2 className="w-8 h-8 animate-spin mb-4" />
          <p className="font-medium">正在計算差異...</p>
        </div>
      ) : diffUrl ? (
        <>
          <div className="flex-1 w-full relative p-4">
            <img 
              src={diffUrl} 
              alt="差異圖" 
              className="w-full h-full object-contain"
            />
            {showInfo && (
              <>
                <ImageInfoOverlay file={images[0].file} label={images[0].label} position="left" />
                <ImageInfoOverlay file={images[1].file} label={images[1].label} position="right" />
              </>
            )}
          </div>
          <div className="absolute bottom-6 right-6">
            <button 
              onClick={handleDownload}
              className="flex items-center gap-2 px-6 py-3 bg-gray-900 text-white rounded-full font-medium hover:bg-gray-800 transition-colors shadow-lg"
            >
              <Download className="w-4 h-4" />
              匯出差異圖
            </button>
          </div>
        </>
      ) : null}
    </div>
  );
}
