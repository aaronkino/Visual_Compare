import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, Columns, Grid2x2, ScanLine, Trash2, Image as ImageIcon, FolderOpen, MousePointerClick, Maximize, Minimize, ChevronLeft, ChevronRight, ChevronUp, ChevronDown } from 'lucide-react';
import { SplitView } from './components/SplitView';
import { GridView } from './components/GridView';
import { DiffView } from './components/DiffView';
import { SequenceView } from './components/SequenceView';
import { ViewImage } from './types';

type ViewMode = 'split' | 'grid' | 'diff' | 'sequence';
type TabMode = 'directory' | 'manual';

export default function App() {
  const [viewMode, setViewMode] = useState<ViewMode>('split');
  const [activeTab, setActiveTab] = useState<TabMode>('directory');
  const [showInfo, setShowInfo] = useState(true);
  const [hideSingletons, setHideSingletons] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isHeaderOpen, setIsHeaderOpen] = useState(true);

  // Directory State
  const [dirFiles, setDirFiles] = useState<File[][]>([[], [], [], []]);
  const [dirNames, setDirNames] = useState<string[]>(['', '', '', '']);
  const [selectedFilename, setSelectedFilename] = useState<string | null>(null);

  // Manual State
  const [manualFiles, setManualFiles] = useState<File[]>([]);
  const [manualSelectedIds, setManualSelectedIds] = useState<string[]>([]);

  // Handle Directory Selection
  const handleDirSelect = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
    const files = Array.from(e.target.files || []) as File[];
    
    // Filter out files in subdirectories (webkitRelativePath should have exactly 2 parts: "Folder/file.jpg")
    const rootFiles = files.filter(f => {
      if (!f.webkitRelativePath) return true;
      return f.webkitRelativePath.split('/').length === 2;
    });

    const imageFiles = rootFiles.filter(f => f.type.startsWith('image/'));
    if (imageFiles.length === 0) return;

    // Try to extract directory name from webkitRelativePath
    const firstPath = imageFiles[0].webkitRelativePath;
    const dirName = firstPath ? firstPath.split('/')[0] : `目錄 ${index + 1}`;

    setDirFiles(prev => {
      const newDirs = [...prev];
      newDirs[index] = imageFiles;
      return newDirs;
    });

    setDirNames(prev => {
      const newNames = [...prev];
      newNames[index] = dirName;
      return newNames;
    });
  };

  // Handle Manual Upload
  const onDrop = useCallback((acceptedFiles: File[]) => {
    setManualFiles(prev => {
      const newFiles = [...prev, ...acceptedFiles];
      // Auto-select first two if not selected
      if (manualSelectedIds.length < 2) {
        const idsToSelect = newFiles.slice(0, 2).map(f => f.name + f.lastModified);
        setManualSelectedIds(idsToSelect);
      }
      return newFiles;
    });
  }, [manualSelectedIds]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop,
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png']
    }
  } as any);

  const toggleManualSelection = (id: string) => {
    setManualSelectedIds(prev => {
      if (prev.includes(id)) {
        return prev.filter(x => x !== id);
      } else {
        // Max 4 selections
        if (prev.length >= 4) {
          return [...prev.slice(1), id];
        }
        return [...prev, id];
      }
    });
  };

  const removeManualFile = (file: File) => {
    const id = file.name + file.lastModified;
    setManualFiles(prev => prev.filter(f => (f.name + f.lastModified) !== id));
    setManualSelectedIds(prev => prev.filter(x => x !== id));
  };

  // Compute Matched Filenames for Directory Mode
  const matchedFilenames = useMemo(() => {
    const counts: Record<string, number> = {};
    const originalNames: Record<string, string> = {};
    
    dirFiles.forEach(files => {
      files.forEach(f => {
        const lowerName = f.name.toLowerCase();
        counts[lowerName] = (counts[lowerName] || 0) + 1;
        if (!originalNames[lowerName]) {
          originalNames[lowerName] = f.name;
        }
      });
    });
    
    let result = Object.entries(counts)
      .map(([lowerName, count]) => ({ lowerName, name: originalNames[lowerName], count }))
      .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
      
    if (hideSingletons) {
      result = result.filter(x => x.count > 1);
    }
    
    return result;
  }, [dirFiles, hideSingletons]);

  // Auto-select first matched filename if none selected
  useEffect(() => {
    if (activeTab === 'directory' && !selectedFilename && matchedFilenames.length > 0) {
      setSelectedFilename(matchedFilenames[0].lowerName);
    }
  }, [activeTab, matchedFilenames, selectedFilename]);

  // Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      if (e.key === 'f' || e.key === 'F') {
        setIsFullscreen(prev => !prev);
      } else if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
        if (activeTab === 'directory' && matchedFilenames.length > 0) {
          e.preventDefault();
          const currentIndex = matchedFilenames.findIndex(m => m.lowerName === selectedFilename);
          if (currentIndex !== -1) {
            if (e.key === 'ArrowUp' && currentIndex > 0) {
              setSelectedFilename(matchedFilenames[currentIndex - 1].lowerName);
              // Scroll into view logic could be added here if needed
            } else if (e.key === 'ArrowDown' && currentIndex < matchedFilenames.length - 1) {
              setSelectedFilename(matchedFilenames[currentIndex + 1].lowerName);
            }
          }
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [activeTab, matchedFilenames, selectedFilename]);

  // Generate ViewImages
  const [viewImages, setViewImages] = useState<ViewImage[]>([]);

  useEffect(() => {
    let filesToView: { file: File, label: string }[] = [];

    if (activeTab === 'directory') {
      if (selectedFilename) {
        filesToView = dirFiles.map((files, i) => {
          const file = files.find(f => f.name.toLowerCase() === selectedFilename);
          return file ? { file, label: dirNames[i] || `目錄 ${i + 1}` } : null;
        }).filter(Boolean) as { file: File, label: string }[];
      }
    } else {
      filesToView = manualFiles
        .filter(f => manualSelectedIds.includes(f.name + f.lastModified))
        .map((file, i) => ({ file, label: `圖片 ${i + 1}` }));
    }

    const newViewImages = filesToView.map(item => ({
      id: item.file.name + item.file.lastModified + item.label,
      url: URL.createObjectURL(item.file),
      file: item.file,
      label: item.label
    }));

    setViewImages(newViewImages);

    return () => {
      newViewImages.forEach(img => URL.revokeObjectURL(img.url));
    };
  }, [activeTab, selectedFilename, dirFiles, dirNames, manualFiles, manualSelectedIds]);

  return (
    <div className="h-screen flex flex-col bg-[#f5f5f5] text-gray-900 font-sans overflow-hidden">
      {/* Header */}
      {isHeaderOpen && !isFullscreen && (
        <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between shrink-0 z-40 relative">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gray-900 text-white rounded-xl flex items-center justify-center shadow-sm">
              <ScanLine className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-semibold tracking-tight">視覺比對工具</h1>
              <p className="text-xs text-gray-500 font-medium uppercase tracking-wider">Visual Compare</p>
            </div>
          </div>
          
          <div className="flex items-center gap-6">
            <button
              onClick={() => setIsFullscreen(true)}
              className="flex items-center gap-2 text-sm font-medium text-gray-700 bg-white border border-gray-200 px-3 py-1.5 rounded-lg hover:bg-gray-50 transition-colors shadow-sm"
              title="全螢幕模式 (快速鍵: F)"
            >
              <Maximize className="w-4 h-4" />
              全螢幕
            </button>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 bg-gray-100 px-3 py-1.5 rounded-full cursor-pointer hover:bg-gray-200 transition-colors">
              <input 
                type="checkbox" 
                checked={showInfo} 
                onChange={e => setShowInfo(e.target.checked)} 
                className="rounded text-gray-900 focus:ring-gray-900" 
              />
              顯示圖片資訊 (EXIF)
            </label>

            <div className="flex items-center gap-2 bg-gray-100 p-1 rounded-full border border-gray-200">
              <button 
                onClick={() => setViewMode('split')}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all ${viewMode === 'split' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-900'}`}
              >
                <Columns className="w-4 h-4" />
                左右分割
              </button>
              <button 
                onClick={() => setViewMode('sequence')}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all ${viewMode === 'sequence' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-900'}`}
              >
                <MousePointerClick className="w-4 h-4" />
                點擊切換
              </button>
              <button 
                onClick={() => setViewMode('grid')}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all ${viewMode === 'grid' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-900'}`}
              >
                <Grid2x2 className="w-4 h-4" />
                四宮格
              </button>
              <button 
                onClick={() => setViewMode('diff')}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all ${viewMode === 'diff' ? 'bg-white shadow-sm text-gray-900' : 'text-gray-500 hover:text-gray-900'}`}
              >
                <ScanLine className="w-4 h-4" />
                差異圖
              </button>
            </div>
          </div>
        </header>
      )}

      <main className="flex-1 flex overflow-hidden relative">
        {/* Header Toggle Button (when hidden) */}
        {!isHeaderOpen && !isFullscreen && (
          <button 
            onClick={() => setIsHeaderOpen(true)}
            className="absolute top-0 left-1/2 -translate-x-1/2 z-50 bg-white border border-t-0 border-gray-200 px-4 py-1 rounded-b-lg shadow-sm text-gray-500 hover:text-gray-900 transition-colors"
            title="顯示上方選單"
          >
            <ChevronDown className="w-4 h-4" />
          </button>
        )}
        {/* Header Toggle Button (when shown) */}
        {isHeaderOpen && !isFullscreen && (
          <button 
            onClick={() => setIsHeaderOpen(false)}
            className="absolute top-0 left-1/2 -translate-x-1/2 z-50 bg-white border border-t-0 border-gray-200 px-4 py-1 rounded-b-lg shadow-sm text-gray-500 hover:text-gray-900 transition-colors"
            title="隱藏上方選單"
          >
            <ChevronUp className="w-4 h-4" />
          </button>
        )}

        {/* Sidebar */}
        {isSidebarOpen && !isFullscreen && (
          <aside className="w-80 shrink-0 bg-white border-r border-gray-200 flex flex-col h-full overflow-hidden relative z-30">
            <div className="flex border-b border-gray-200 shrink-0">
            <button 
              onClick={() => setActiveTab('directory')} 
              className={`flex-1 py-3 text-sm font-medium border-b-2 transition-colors ${activeTab === 'directory' ? 'border-gray-900 text-gray-900 bg-gray-50' : 'border-transparent text-gray-500 hover:bg-gray-50'}`}
            >
              目錄比對
            </button>
            <button 
              onClick={() => setActiveTab('manual')} 
              className={`flex-1 py-3 text-sm font-medium border-b-2 transition-colors ${activeTab === 'manual' ? 'border-gray-900 text-gray-900 bg-gray-50' : 'border-transparent text-gray-500 hover:bg-gray-50'}`}
            >
              手動選擇
            </button>
          </div>

          <div className="flex-1 overflow-y-auto">
            {activeTab === 'directory' ? (
              <div className="p-6 space-y-6">
                <div className="space-y-4">
                  {[0, 1, 2, 3].map(i => (
                    <div key={i}>
                      <label className="block text-xs font-bold text-gray-500 uppercase mb-2">
                        目錄 {i + 1} {dirNames[i] && <span className="text-blue-600 normal-case ml-1">({dirNames[i]})</span>}
                      </label>
                      <div className="relative">
                        <input
                          type="file"
                          // @ts-ignore
                          webkitdirectory=""
                          directory=""
                          multiple
                          onChange={(e) => handleDirSelect(e, i)}
                          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        />
                        <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-100 transition-colors">
                          <FolderOpen className="w-4 h-4 text-gray-500" />
                          {dirFiles[i].length > 0 ? `已載入 ${dirFiles[i].length} 個檔案` : '選擇目錄...'}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                
                {matchedFilenames.length > 0 && (
                  <div className="pt-4 border-t border-gray-200">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="text-xs font-bold text-gray-500 uppercase">比對檔案 ({matchedFilenames.length})</h3>
                    </div>
                    <label className="flex items-center gap-2 text-xs font-medium text-gray-600 mb-3 cursor-pointer hover:text-gray-900 transition-colors">
                      <input 
                        type="checkbox" 
                        checked={hideSingletons} 
                        onChange={e => setHideSingletons(e.target.checked)} 
                        className="rounded text-gray-900 focus:ring-gray-900" 
                      />
                      隱藏無從比較的單一檔案
                    </label>
                    <div className="space-y-1 pr-2">
                      {matchedFilenames.map(({lowerName, name, count}) => (
                        <button
                          key={lowerName}
                          onClick={() => setSelectedFilename(lowerName)}
                          className={`w-full text-left px-3 py-2 rounded-lg text-sm flex items-center justify-between transition-colors ${selectedFilename === lowerName ? 'bg-gray-900 text-white' : 'hover:bg-gray-100 text-gray-700'}`}
                        >
                          <span className="truncate pr-2 flex-1 min-w-0">{name}</span>
                          <span className={`shrink-0 text-xs px-2 py-0.5 rounded-full font-mono ${selectedFilename === lowerName ? 'bg-gray-700 text-gray-200' : 'bg-gray-200 text-gray-500'}`}>
                            {count}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="p-6">
                <div 
                  {...getRootProps()} 
                  className={`border-2 border-dashed rounded-2xl p-6 flex flex-col items-center justify-center text-center cursor-pointer transition-colors ${isDragActive ? 'border-gray-900 bg-gray-50' : 'border-gray-300 hover:border-gray-400 hover:bg-gray-50'}`}
                >
                  <input {...getInputProps()} />
                  <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mb-3">
                    <Upload className="w-5 h-5 text-gray-600" />
                  </div>
                  <p className="text-sm font-medium text-gray-900 mb-1">上傳圖片</p>
                  <p className="text-xs text-gray-500">拖曳或點擊選擇檔案</p>
                </div>

                {manualFiles.length > 0 && (
                  <div className="mt-6">
                    <h3 className="text-xs font-bold text-gray-500 uppercase mb-3">已上傳檔案 ({manualFiles.length})</h3>
                    <p className="text-xs text-gray-400 mb-3">請勾選要比對的圖片 (最多 4 張)</p>
                    <div className="space-y-2">
                      {manualFiles.map(file => {
                        const id = file.name + file.lastModified;
                        const isSelected = manualSelectedIds.includes(id);
                        return (
                          <div key={id} className={`group flex items-center gap-3 p-2 rounded-xl border transition-colors ${isSelected ? 'bg-blue-50 border-blue-200' : 'bg-gray-50 border-gray-200 hover:border-gray-300'}`}>
                            <label className="flex items-center gap-3 flex-1 cursor-pointer min-w-0">
                              <input 
                                type="checkbox" 
                                checked={isSelected}
                                onChange={() => toggleManualSelection(id)}
                                className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4 ml-1"
                              />
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium text-gray-900 truncate">{file.name}</p>
                                <p className="text-xs text-gray-500 font-mono mt-0.5">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                              </div>
                            </label>
                            <button 
                              onClick={() => removeManualFile(file)}
                              className="p-2 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                              title="移除圖片"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        </aside>
        )}

        {/* Sidebar Toggle Button */}
        {!isFullscreen && (
          <button 
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className={`absolute top-1/2 -translate-y-1/2 z-40 bg-white border border-gray-200 py-4 px-1 rounded-r-lg shadow-sm text-gray-500 hover:text-gray-900 transition-all ${isSidebarOpen ? 'left-80 border-l-0' : 'left-0'}`}
            title={isSidebarOpen ? "隱藏側邊欄" : "顯示側邊欄"}
          >
            {isSidebarOpen ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
        )}

        {/* Main Content Area */}
        <section className={isFullscreen ? "fixed inset-0 z-[100] bg-black flex flex-col p-4" : "flex-1 min-w-0 p-6 overflow-hidden flex flex-col relative z-20"}>
          {isFullscreen && (
            <button
              onClick={() => setIsFullscreen(false)}
              className="absolute top-6 left-6 z-[1000] bg-white/20 text-white p-2 rounded-full hover:bg-white/30 backdrop-blur-md border border-white/10 shadow-lg transition-colors"
              title="退出全螢幕"
            >
              <Minimize className="w-5 h-5" />
            </button>
          )}
          {viewImages.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center text-center max-w-md mx-auto">
              <div className="w-20 h-20 bg-white rounded-3xl shadow-sm border border-gray-200 flex items-center justify-center mb-6">
                <ImageIcon className="w-8 h-8 text-gray-300" />
              </div>
              <h2 className="text-2xl font-semibold mb-2">尚未選擇圖片</h2>
              <p className="text-gray-500">
                {activeTab === 'directory' 
                  ? '請從左側選擇目錄，並點擊下方清單中的檔名來進行比對。' 
                  : '請上傳圖片並勾選至少兩張圖片進行比對。'}
              </p>
            </div>
          ) : (
            <div className="flex-1 w-full h-full relative">
              {viewMode === 'split' && (
                <SplitView images={viewImages} showInfo={showInfo} />
              )}
              
              {viewMode === 'sequence' && (
                <SequenceView images={viewImages} showInfo={showInfo} />
              )}

              {viewMode === 'grid' && (
                <GridView images={viewImages} showInfo={showInfo} />
              )}
              
              {viewMode === 'diff' && (
                <DiffView images={viewImages} showInfo={showInfo} />
              )}
            </div>
          )}
        </section>
      </main>
    </div>
  );
}
