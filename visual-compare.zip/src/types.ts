export interface ViewImage {
  id: string;
  url: string;
  file: File;
  label: string;
}
